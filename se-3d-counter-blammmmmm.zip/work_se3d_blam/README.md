
# se-3d-counter (for GitHub Pages) — blammmmmm

Two paths:

A) PIXI-only preview (works now, no CDNs): open `widget/pixi_preview.html`.
B) Three.js 3D: replace vendor placeholders in /lib and /fonts with real files from Three.js when you can download them, then point your StreamElements widget BASE to:
https://blammmmmm.github.io/se-3d-counter
